export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyA_QvA6gsmiCU7fPKeCC4tfTJX6bZjC69w",
    authDomain: "strcutural-engine.firebaseapp.com",
    databaseURL: "https://strcutural-engine-default-rtdb.firebaseio.com",
    projectId: "strcutural-engine",
    storageBucket: "strcutural-engine.appspot.com",
    messagingSenderId: "424393809904",
    appId: "1:424393809904:web:da2eb60ab855cf4e76c735"
  },
  calcURL: 'http://localhost:7009/api/Function1',
  loginURL: 'https://platform.structuralengine.com',
  GH_TOKEN: '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'
};
