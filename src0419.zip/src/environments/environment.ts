export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyA_QvA6gsmiCU7fPKeCC4tfTJX6bZjC69w",
    authDomain: "strcutural-engine.firebaseapp.com",
    databaseURL: "https://strcutural-engine-default-rtdb.firebaseio.com",
    projectId: "strcutural-engine",
    storageBucket: "strcutural-engine.appspot.com",
    messagingSenderId: "424393809904",
    appId: "1:424393809904:web:da2eb60ab855cf4e76c735"
  },
  calcURL: 'https://webdan.azurewebsites.net/api/Function1?code=4U4ejr0vIe5iJ8Bu2begDfq5RJ0m6cEjF9f9zj-O5_t4AzFuiXfSLA==',
  loginURL: 'https://platform.structuralengine.com',
};
